## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/universal-react-with-next-js-the-ultimate-guide-video/9781839210792)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Universal-React-with-Next.js---The-Ultimate-Guide
Code Repository for Universal React with Next.js - The Ultimate Guide, Published by Packt
